/*  =========  typing animation  =========  */
var typed = new Typed(".typing",{
    strings:["Web Developer","Frontend Developer",],
    typeSpeed:100,
    BackSpeed:60,
    loop:true
})